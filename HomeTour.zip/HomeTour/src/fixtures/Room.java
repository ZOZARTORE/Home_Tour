package fixtures;

public class Room extends Fixture{
	
	public Room[] exits;

	public Room(String name, String shortDesc, String longDesc) {
		super(name, shortDesc, longDesc);
		this.exits = new Room[4]; // size is your choice
	}
}
