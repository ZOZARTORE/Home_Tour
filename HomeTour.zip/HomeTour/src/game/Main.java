package game;

import java.util.Scanner;
import game.RoomManager;

public class Main {
static String[] in;
	static Scanner search = new Scanner(System.in);
	public static void main(String[] args) {
		Player player = new Player();
		player.currentRoom = 0;
		RoomManager rm = new RoomManager();
		rm.init();
		printRoom(rm,player);
		do {
		in = collectInput();
		parse(rm,in,player);
		}while(in[0] != "exit");
	}
		
	private static void printRoom(RoomManager rm,Player player) {
		System.out.println(rm.rooms.get(player.currentRoom).longDesc);
	}

	private static String[] collectInput() {
		String input = search.nextLine();
		String[] command = input.split(" ");
		return command;
		
	}
		
	private static void parse(RoomManager rm, String[] command, Player player) {
		switch(command[0]){
		case "go":
			switch(command[1]) {
			case "north":
				if(rm.northIs[player.currentRoom] != 9) {
					player.currentRoom = rm.northIs[player.currentRoom];
					System.out.println(rm.rooms.get(player.currentRoom).longDesc);
				}else {
					System.out.println("you walk into a wall.");
				}
				break;
			case "east":
				if(rm.eastIs[player.currentRoom] != 9) {
					player.currentRoom = rm.eastIs[player.currentRoom];
					System.out.println(rm.rooms.get(player.currentRoom).longDesc);
				}else {
					System.out.println("you walk into a wall.");
				}
				break;
			case "south":
				if(rm.southIs[player.currentRoom] != 9) {
					player.currentRoom = rm.southIs[player.currentRoom];
					System.out.println(rm.rooms.get(player.currentRoom).longDesc);
				}else {
					System.out.println("you walk into a wall.");
				}
				break;
			case "west":
				if(rm.westIs[player.currentRoom] != 9) {
					player.currentRoom = rm.westIs[player.currentRoom];
					System.out.println(rm.rooms.get(player.currentRoom).longDesc);
				}else {
					System.out.println("you walk into a wall.");
					
				}
				break;
			}
			break;
		case "look":
			switch(command[command.length-1]) {
			case "around":
				System.out.println(rm.rooms.get(player.currentRoom).longDesc);
				break;
			case "room":
				System.out.println(rm.rooms.get(player.currentRoom).longDesc);
				break;
			}
			break;
		case "inspect":
			switch(command[command.length-1]) {
			case "around":
				System.out.println(rm.rooms.get(player.currentRoom).longDesc);
				break;
			case "room":
				System.out.println(rm.rooms.get(player.currentRoom).longDesc);
				break;
			}
			break;
		}
	}
}
