package game;

public class Player {
	public int currentRoom;
	
}
