package game;

import fixtures.Room;
import java.util.ArrayList;

public class RoomManager {
	ArrayList<Room> rooms = new ArrayList<Room>();
	int[] northIs = {3,7,8,9,9,2,9,9,9,9};
	int[] eastIs = {2,9,4,6,9,9,9,9,9,9};
	int[] southIs = {9,9,5,0,9,9,9,1,2,9};
	int[] westIs = {1,9,0,9,2,9,3,9,9,9};
	public void init() {
		
	    Room hallOne = new Room(
			"The Entrance Hallway",
			"a small foyer",
			"An entry hallway that stretches north to a living room" + "\n"
			+ "The hardwood floor leads west into doorway. To the east another hall continues." + "\n"
			+ "To the south is the front entrance.");
		rooms.add(hallOne);
	    Room bedroomOne = new Room(
			"The Master Bedroom",
			"A large Bedroom",
			"A large bedroom carpeted with a computer in the corner and a bed in the center." + "\n"
			+ "To the north is a bathroom and to the east is the main hallway");
	    rooms.add(bedroomOne);
	    Room HallTwo = new Room(
			"The Side Hallway",
			"a small hallway",
			"A small hallway connecting to a restroom to the north and two bedrooms," + "\n"
			+ "one to the east and one to the south. The main hallway is to the west.");
	    rooms.add(HallTwo);
	    Room LivingRoom = new Room(
			"The Living Room",
			"a large living area",
			"A large living area that contains a long couch on the north wall and a tv facing it from the south with a coffe table in between"+ "\n"+
			"To the east is the kitchen with no walls between the rooms and to the south is the main hallway.");
	    rooms.add(LivingRoom);
		Room bedroomTwo = new Room(
				"The Second Bedroom",
				"a small bedroom",
				"A small carpeted bedroom with a long desk along the entire east wall with a computer with 2 moniters." + "\n"
				+ "The only door is the one back west");
		rooms.add(bedroomTwo);
		Room bedroomThree = new Room(
				"The Third Bedroom",
				"a small bedroom",
				"A small carpeted bedroom with a bed in the southeast corner facing a tv on the north wall." + "\n"
				+ "There are multiple dressers that dont match along the east wall." + "\n"
				+ "To the north is the small side hallway.");
		rooms.add(bedroomThree);
		Room kitchen = new Room(
				"The Kitchen",
				"an open kitchen",
				"The kitchen has no barrier between it and the living roomto the west." + "\n"
				+ "The floor is tiled and there is a fridge to the south." + "\n"
				+ "To the east is a long counter with many cabinets and a built in stove."+ "\n"
				+ "in the center there is an island that contains a sink and dishwasher.");
		rooms.add(kitchen);
		Room masterBathroom = new Room(
				"The Master Bathroom",
				"a large bathroom",
				"The floor is tiled and to the west is a full size tub next to a glass encased shower."+ "\n"
				+ "To the east is the sink and a toilet. The door to the south has a pull up bar hanging from the frame.");
		rooms.add(masterBathroom);
		Room guestBathroom = new Room(
				"The Guest Bathroom",
				"a small bathroom",
				"The floor is tiled and there is a tub/shower combo on the north wall."+ "\n"
				+ "The east wall has a toilet next to the tub and a sink next to the door to the south.");
		rooms.add(guestBathroom);
		Room wall = new Room(
				"A wall",
				"It's a wall",
				"It's a wall.");
		rooms.add(wall);

		
	}
	public String getExits(int currentRoom) {
		String directions = new String();
		directions = "To the north is "+rooms.get(northIs[currentRoom]).name+". To the east is "+rooms.get(eastIs[currentRoom]).name+
				". To the south is "+rooms.get(southIs[currentRoom]).name+". To the west is "+rooms.get(westIs[currentRoom]).name;
		return directions;
	}
}
